package school.cesar.sd.attend.attendserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
