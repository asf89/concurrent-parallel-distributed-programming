package school.cesar.sd.attend.attendserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendServerApplication.class, args);
	}

}
