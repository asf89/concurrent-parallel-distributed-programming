package school.cesar.sd.messageproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessageproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessageproducerApplication.class, args);
	}

}
